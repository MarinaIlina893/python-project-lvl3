from page_loader.download import download

__all__ = ['download']
